# Simple E-commerce Store (Django)

A beginner-friendly e-commerce starter project with:
- Product listing and product detail pages
- Session-based shopping cart
- Registration, login and logout
- Checkout and order creation
- SQLite database for products, users and orders
- Django admin for managing products and orders

## 1. Setup

Python 3.10+ is recommended.

```bash
python -m venv venv
```

Activate the environment:

**Windows**
```bash
venv\\Scripts\\activate
```

**macOS/Linux**
```bash
source venv/bin/activate
```

Install dependencies and prepare the database:

```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/ in your browser.
Admin: http://127.0.0.1:8000/admin/

## 2. Add products

Sign in to Django admin with your superuser account. Add products under **Products**.
Products can have a name, description, price, stock quantity and optional image URL.

## 3. Test the store

1. Register a customer account.
2. Open a product and add it to the cart.
3. Change quantities or remove cart items.
4. Sign in and complete checkout.
5. Check the created order in Django admin.

## Notes

- This is a learning/demo project. Checkout creates an order but does not collect payment.
- Before production, configure environment-based SECRET_KEY, DEBUG=False, HTTPS, email verification,
  CSRF/security settings, payment gateway, image uploads and deployment.
- The default database is SQLite (`db.sqlite3`), created automatically by migrations.
