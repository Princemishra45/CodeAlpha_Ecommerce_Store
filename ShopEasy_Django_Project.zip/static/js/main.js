// Small frontend enhancement: confirm before placing an order.
document.addEventListener("DOMContentLoaded", () => {
  const checkoutForm = document.querySelector(".form-panel form");
  if (checkoutForm) {
    checkoutForm.addEventListener("submit", (event) => {
      if (!window.confirm("Place this order?")) event.preventDefault();
    });
  }
});
