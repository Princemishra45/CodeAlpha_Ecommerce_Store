from decimal import Decimal
from .models import Product

CART_SESSION_KEY = "cart"

def get_cart(request):
    raw_cart = request.session.get(CART_SESSION_KEY, {})
    cart = []
    total = Decimal("0.00")
    for product_id, quantity in raw_cart.items():
        try:
            product = Product.objects.get(pk=int(product_id))
            quantity = max(1, int(quantity))
        except (Product.DoesNotExist, ValueError, TypeError):
            continue
        subtotal = product.price * quantity
        cart.append({"product": product, "quantity": quantity, "subtotal": subtotal})
        total += subtotal
    return cart, total
