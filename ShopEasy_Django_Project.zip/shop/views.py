from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from .cart import CART_SESSION_KEY, get_cart
from .forms import CheckoutForm
from .models import Product, Order, OrderItem

def home(request):
    products = Product.objects.all()
    return render(request, "shop/home.html", {"products": products})

def product_detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    return render(request, "shop/product_detail.html", {"product": product})

def add_to_cart(request, product_id):
    if request.method != "POST":
        return redirect("product_detail", product_id=product_id)
    product = get_object_or_404(Product, pk=product_id)
    cart = request.session.get(CART_SESSION_KEY, {})
    current = int(cart.get(str(product_id), 0))
    if current + 1 > product.stock:
        messages.error(request, "Sorry, there is not enough stock available.")
    else:
        cart[str(product_id)] = current + 1
        request.session[CART_SESSION_KEY] = cart
        messages.success(request, "Product added to your cart.")
    return redirect("cart")

def cart_view(request):
    cart, total = get_cart(request)
    return render(request, "shop/cart.html", {"cart": cart, "total": total})

def update_cart(request, product_id):
    if request.method == "POST":
        cart = request.session.get(CART_SESSION_KEY, {})
        product = get_object_or_404(Product, pk=product_id)
        try:
            quantity = int(request.POST.get("quantity", "1"))
        except ValueError:
            quantity = 1
        if quantity <= 0:
            cart.pop(str(product_id), None)
        elif quantity <= product.stock:
            cart[str(product_id)] = quantity
        else:
            messages.error(request, f"Only {product.stock} item(s) are currently in stock.")
        request.session[CART_SESSION_KEY] = cart
    return redirect("cart")

def remove_from_cart(request, product_id):
    if request.method == "POST":
        cart = request.session.get(CART_SESSION_KEY, {})
        cart.pop(str(product_id), None)
        request.session[CART_SESSION_KEY] = cart
    return redirect("cart")

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("home")
    else:
        form = UserCreationForm()
    return render(request, "shop/register.html", {"form": form})

@login_required
def checkout(request):
    cart, total = get_cart(request)
    if not cart:
        messages.info(request, "Your cart is empty.")
        return redirect("home")
    if request.method == "POST":
        form = CheckoutForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                # Re-check stock while creating the order.
                for line in cart:
                    product = Product.objects.select_for_update().get(pk=line["product"].pk)
                    if product.stock < line["quantity"]:
                        messages.error(request, f"Not enough stock for {product.name}.")
                        return redirect("cart")
                order = Order.objects.create(
                    user=request.user,
                    full_name=form.cleaned_data["full_name"],
                    email=form.cleaned_data["email"],
                    address=form.cleaned_data["address"],
                    total=total,
                )
                for line in cart:
                    product = Product.objects.select_for_update().get(pk=line["product"].pk)
                    quantity = line["quantity"]
                    OrderItem.objects.create(
                        order=order, product=product, product_name=product.name,
                        unit_price=product.price, quantity=quantity
                    )
                    product.stock -= quantity
                    product.save(update_fields=["stock"])
                request.session[CART_SESSION_KEY] = {}
            return render(request, "shop/order_success.html", {"order": order})
    else:
        form = CheckoutForm(initial={
            "full_name": request.user.get_full_name(),
            "email": request.user.email,
        })
    return render(request, "shop/checkout.html", {"form": form, "cart": cart, "total": total})

@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items")
    return render(request, "shop/my_orders.html", {"orders": orders})
